import { EstadoBr } from './../models/estado-br.model';
import { map } from 'rxjs/operators';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DropdownService {

  constructor(private httpClient: HttpClient) { }

  getEstadosBr() {
    return this.httpClient.get<EstadoBr[]>('assets/dados/estadosbr.json');
  }
  
}


  // getEstadosBr(){
  //     return this.httpClient.get('assets/dados/estadosbr.json').pipe();
  // }